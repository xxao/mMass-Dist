# -------------------------------------------------------------------------
#     Copyright (C) 2005-2011 Martin Strohalm <www.mmass.org>

#     This program is free software; you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation; either version 3 of the License, or
#     (at your option) any later version.

#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#     GNU General Public License for more details.

#     Complete text of GNU GPL can be found in the file LICENSE.TXT in the
#     main directory of the program
# -------------------------------------------------------------------------

#load libs
import re
import numpy
import copy

# load stopper
from stopper import CHECK_FORCE_QUIT

# register essential objects
import blocks

# register essential modules
import processing
import proteo


# compile basic patterns
formulaPattern = re.compile(r'''
    ^(
        ([\(])* # start parenthesis
        (
            ([A-Z][a-z]{0,2}) # atom symbol
            (\{[\d]+\})? # isotope
            (([\-][\d]+)|[\d]*) # atom count
        )+
        ([\)][\d]*)* # end parenthesis
    )*$
''', re.X)

elementPattern = re.compile(r'''
            ([A-Z][a-z]{0,2}) # atom symbol
            (?:\{([\d]+)\})? # isotope
            ([\-]?[\d]*) # atom count
''', re.X)



# BASIC OBJECTS DEFINITION
# ------------------------

class compound:
    """Compound object definition."""
    
    def __init__(self, expression):
        
        # check formula
        self._checkFormula(expression)
        self.expression = expression
        
        # buffers
        self._composition = None
        self._formula = None
        self._mass = None
        
        # user defined params
        self.userParams = {}
    # ----
    
    
    def __iadd__(self, other):
        """Append formula."""
        
        # check and append value
        if isinstance(other, compound):
            self.expression += other.expression
        else:
            self._checkFormula(other)
            self.expression += other
        
        # clear buffers
        self.reset()
        
        return self
    # ----
    
    
    def reset(self):
        """Clear formula buffers."""
        
        self._composition = None
        self._formula = None
        self._mass = None
    # ----
    
    
    # GETTERS
    
    def count(self, item):
        """Count atom in formula."""
        
        # pre-check atom
        if not item in self.expression:
            return 0
        
        # get composition
        comp = self.composition()
        
        # count atom
        if item in comp:
            return comp[item]
        else:
            return 0
    # ----
    
    
    def formula(self):
        """Get formula."""
        
        # check formula buffer
        if self._formula != None:
            return self._formula
        
        # get composition
        comp = self.composition()
        
        # format composition
        self._formula = ''
        for el in sorted(comp.keys()):
            if comp[el] == 1:
                self._formula += el
            else:
                self._formula += '%s%d' % (el, comp[el])
        
        return self._formula
    # ----
    
    
    def composition(self):
        """Get elemental composition."""
        
        # check composition buffer
        if self._composition != None:
            return self._composition
        
        # unfold brackets
        unfoldedFormula = self._unfoldBrackets(self.expression)
        
        # group elements
        self._composition = {}
        for symbol, isotop, count in elementPattern.findall(unfoldedFormula):
            
            # make atom
            if isotop:
                atom = '%s{%s}' % (symbol, isotop)
            else:
                atom = symbol
            
            # convert counting
            if count:
                count = int(count)
            else:
                count = 1
            
            # add atom
            if atom in self._composition:
                self._composition[atom] += count
            else:
                self._composition[atom] = count
        
        # remove zeros
        for atom in self._composition.keys():
            if self._composition[atom] == 0:
                del self._composition[atom]
        
        return self._composition
    # ----
    
    
    def mass(self, massType=None):
        """Get mass."""
        
        # get mass
        if self._mass == None:
            massMo = 0
            massAv = 0
            
            # get composition
            comp = self.composition()
            
            # get mass for each atom
            for atom in comp:
                count = comp[atom]
                
                # check specified isotope and mass
                match = elementPattern.match(atom)
                symbol, massNumber, tmp = match.groups()
                if massNumber:
                    isotope = blocks.elements[symbol].isotopes[int(massNumber)]
                    atomMass = (isotope[0], isotope[0])
                else:
                    atomMass = blocks.elements[symbol].mass
                
                # multiply atom mass
                massMo += atomMass[0]*count
                massAv += atomMass[1]*count
            
            # store mass in buffer
            self._mass = (massMo, massAv)
        
        # return mass
        if massType == 0:
            return self._mass[0]
        elif massType ==  1:
            return self._mass[1]
        else:
            return self._mass
    # ----
    
    
    def mz(self, charge, agentFormula='H', agentCharge=1):
        """Get ion m/z."""
        
        return processing.mz(self.mass(),
            charge = charge,
            agentFormula = agentFormula,
            agentCharge = agentCharge
        )
    # ----
    
    
    def pattern(self, fwhm=0.1, threshold=0.01, charge=0, agentFormula='H', agentCharge=1):
        """Get isotopic pattern."""
        
        return processing.pattern(self,
            fwhm = fwhm,
            threshold = threshold,
            charge = charge,
            agentFormula = agentFormula,
            agentCharge = agentCharge
        )
    # ----
    
    
    def isvalid(self, charge=0, agentFormula='H', agentCharge=1):
        """Check ion composition."""
        
        # check agent formula
        if agentFormula != 'e' and not isinstance(agentFormula, compound):
            agentFormula = compound(agentFormula)
        
        # make ion compound
        if charge and agentFormula != 'e':
            ionFormula = self.expression
            for atom, count in agentFormula.composition().items():
                ionFormula += '%s%d' % (atom, count*(charge/agentCharge))
            ion = compound(ionFormula)
        else:
            ion = compound(self.expression)
        
        # get composition
        for atom, count in ion.composition().items():
            if count < 0:
                return False
        
        return True
    # ----
    
    
    # MODIFIERS
    
    def negate(self):
        """Make all atom counts negative."""
        
        # get composition
        comp = self.composition()
        
        # negate composition
        formula = ''
        for el in sorted(comp.keys()):
            formula += '%s%d' % (el, -1*comp[el])
        self.expression = formula
        
        # clear buffers
        self.reset()
    # ----
    
    
    # HELPERS
    
    def _checkFormula(self, formula):
        """Check given formula."""
        
        # check formula
        if not formulaPattern.match(formula):
            raise ValueError, 'Wrong formula! --> ' + formula
        
        # check elements and isotopes
        for atom in elementPattern.findall(formula):
            if not atom[0] in blocks.elements:
                raise ValueError, 'Unknown element in formula! --> ' + atom[0] + ' in ' + formula
            elif atom[1] and not int(atom[1]) in blocks.elements[atom[0]].isotopes:
                raise ValueError, 'Unknown isotope in formula! --> ' + atom[0] + atom[1] + ' in ' + formula
        
        # check brackets
        if formula.count(')') != formula.count('('):
            raise ValueError, 'Wrong number of brackets in formula! --> ' + formula
    # ----
    
    
    def _unfoldBrackets(self, string):
        """Unfold formula and count each atom."""
        
        unfoldedFormula = ''
        brackets = [0,0]
        enclosedFormula = ''
        
        i = 0
        while i < len(string):
            
            # handle brackets
            if string[i] == '(':
                brackets[0] += 1
            elif string[i] == ')':
                brackets[1] += 1
            
            # part outside brackets
            if brackets == [0,0]:
                unfoldedFormula += string[i]
            
            # part within brackets
            else:
                enclosedFormula += string[i]
                
                # unfold part within brackets
                if brackets[0] == brackets[1]:
                    enclosedFormula = self._unfoldBrackets(enclosedFormula[1:-1])
                    
                    # multiply part within brackets
                    count = ''
                    while len(string)>(i+1) and string[i+1].isdigit():
                        count += string[i+1]
                        i += 1
                    if count:
                        enclosedFormula = enclosedFormula * int(count)
                    
                    # add and clear
                    unfoldedFormula += enclosedFormula
                    enclosedFormula = ''
                    brackets = [0,0]
            
            i += 1
            
        return unfoldedFormula
    # ----
    


class sequence:
    """Sequence object definition."""
    
    def __init__(self, chain, title='', accession='', chainType='aminoacids', cyclic=False):
        
        self.chain = []
        self.chainType = chainType
        self.cyclic = cyclic
        
        # get sequence chain
        if type(chain) == list:
            self.chain = chain
        
        elif self.chainType == 'aminoacids':
            for symbol in chain.upper():
                if not symbol in ('\t','\n','\r','\f','\v', ' ', '-', '*', '.', ''):
                    self.chain.append(symbol)
        else:
            for symbol in chain.split('|'):
                symbol = symbol.strip()
                if not symbol in ('\t','\n','\r','\f','\v', ' ', '-', '*', '.', ''):
                    self.chain.append(symbol)
        
        for monomer in self.chain:
            if not monomer in blocks.monomers:
                raise KeyError, 'Unknown monomer in the sequence! --> ' + monomer
        
        # set terminal groups
        if self.cyclic:
            self.nTermFormula = ''
            self.cTermFormula = ''
        else:
            self.nTermFormula = 'H'
            self.cTermFormula = 'OH'
        
        # [[name, position=[#|symbol], state=[f|v]], ] (f->fixed, v->variable)
        self.modifications = []
        self.labels = []
        
        # for proteins
        self.title = title
        self.accession = accession
        self.orgName = ''
        self.pi = None
        self.score = None
        
        # for peptides
        self.history = [('init', 0, len(self.chain))]
        self.itemBefore = ''
        self.itemAfter = ''
        self.miscleavages = 0
        
        # for fragments
        self.fragmentSerie = None
        self.fragmentIndex = None
        self.fragmentLosses = []
        self.fragmentGains = []
        self.fragmentFiltered = False
        
        # buffers
        self._formula = None
        self._composition = None
        self._mass = None
        
        # user defined params
        self.userParams = {}
    # ----
    
    
    def __nonzero__(self):
        """Check sequence length."""
        return bool(len(self.chain))
    # ----
    
    
    def __len__(self):
        """Get sequence length."""
        return len(self.chain)
    # ----
    
    
    def __getitem__(self, i):
        return self.chain[i]
    # ----
    
    
    def __getslice__(self, start, stop):
        """Get slice of the sequence."""
        
        # check slice
        if stop < start and not self.cyclic:
            raise ValueError, 'Invalid slice!'
        
        # break the links
        parent = copy.deepcopy(self)
        
        # check slice
        start = max(start, 0)
        stop = min(stop, len(parent))
        
        # make new sequence object
        if start < stop:
            seq = parent.chain[start:stop]
            peptide = sequence(seq, chainType=parent.chainType, cyclic=False)
        elif self.cyclic:
            seq = parent.chain[start:] + parent.chain[:stop]
            peptide = sequence(seq, chainType=parent.chainType, cyclic=False)
        
        # add previous history
        peptide.history = parent.history
        
        # add fragment losses and gains
        peptide.fragmentLosses = parent.fragmentLosses
        peptide.fragmentGains = parent.fragmentGains
        
        # add modifications
        for mod in parent.modifications:
            if type(mod[1]) in (str, unicode) and mod[1] in peptide.chain:
                peptide.modifications.append(mod)
            elif type(mod[1]) == int:
                if start <= mod[1] < stop:
                    mod[1] -= start
                    peptide.modifications.append(mod)
                elif start >= stop and mod[1] >= start:
                    mod[1] -= start
                    peptide.modifications.append(mod)
                elif start >= stop and mod[1] < stop:
                    mod[1] += len(parent) - start
                    peptide.modifications.append(mod)
        
        # add labels
        for mod in parent.labels:
            if type(mod[1]) in (str, unicode) and mod[1] in peptide.chain:
                peptide.labels.append(mod)
            elif type(mod[1]) == int:
                if start <= mod[1] < stop:
                    mod[1] -= start
                    peptide.labels.append(mod)
                elif start >= stop and mod[1] >= start:
                    mod[1] -= start
                    peptide.labels.append(mod)
                elif start >= stop and mod[1] < stop:
                    mod[1] += len(parent) - start
                    peptide.labels.append(mod)
        
        # add terminal modifications
        if start == 0:
            peptide.nTermFormula = parent.nTermFormula
        if stop >= len(parent):
            peptide.cTermFormula = parent.cTermFormula
        if parent.cyclic:
            peptide.nTermFormula = 'H'
            peptide.cTermFormula = 'OH'
        
        # set adjacent monomers
        if start > 0 or parent.cyclic:
            peptide.itemBefore = parent.chain[start-1]
        if stop < len(parent):
            peptide.itemAfter = parent.chain[stop]
        if stop == len(parent) and parent.cyclic:
            peptide.itemAfter = parent.chain[0]
        
        # add to history
        peptide.history.append(('slice', start, stop))
        
        # ensure buffers are cleaned
        peptide.reset()
        
        return peptide
    # ----
    
    
    def __setslice__(self, start, stop, value):
        """Insert sequence object (essential for sequence editor)."""
        
        # check slice
        if stop < start:
            raise ValueError, 'Invalid slice!'
        
        # check value
        if not isinstance(value, sequence):
            raise TypeError, 'Invalid object to instert!'
        
        # check chain type
        if value.chainType != self.chainType:
            raise TypeError, 'Invalid chain type to instert!'
        
        # break the links
        value = copy.deepcopy(value)
        
        # delete slice
        if stop != start:
            del(self[start:stop])
        
        # insert sequence
        self.chain = self.chain[:start] + value.chain + self.chain[start:]
        
        # shift modifications
        for x, mod in enumerate(self.modifications):
            if type(mod[1]) == int and mod[1] >= start:
                self.modifications[x][1] += (len(value))
        
        # shift labels
        for x, mod in enumerate(self.labels):
            if type(mod[1]) == int and mod[1] >= start:
                self.labels[x][1] += (len(value))
        
        # insert modifications
        for mod in value.modifications:
            if type(mod[1]) == int:
                mod[1] += start
            self.modifications.append(mod)
        
        # insert labels
        for mod in value.labels:
            if type(mod[1]) == int:
                mod[1] += start
            self.labels.append(mod)
        
        # clear some values
        self.history = [('init', 0, len(self.chain))]
        self.itemBefore = ''
        self.itemAfter = ''
        self.miscleavages = 0
        
        # clear buffers
        self.reset()
    # ----
    
    
    def __delslice__(self, start, stop):
        """Delete slice of sequence (essential for sequence editor)."""
        
        # check slice
        if stop < start:
            raise ValueError, 'Invalid slice!'
        
        # remove sequence
        self.chain = self.chain[:start] + self.chain[stop:]
        
        # remove modifications
        keep = []
        for mod in self.modifications:
            if type(mod[1]) == int and (mod[1] < start or mod[1] >= stop):
                if mod[1] >= stop:
                    mod[1] -= (stop - start)
                keep.append(mod)
            elif type(mod[1]) in (str, unicode) and mod[1] in self.chain:
                keep.append(mod)
        self.modifications = keep
        
        # remove labels
        keep = []
        for mod in self.labels:
            if type(mod[1]) == int and (mod[1] < start or mod[1] >= stop):
                if mod[1] >= stop:
                    mod[1] -= (stop - start)
                keep.append(mod)
            elif type(mod[1]) in (str, unicode) and mod[1] in self.chain:
                keep.append(mod)
        self.labels = keep
        
        # clear some values
        self.history = [('init', 0, len(self.chain))]
        self.itemBefore = ''
        self.itemAfter = ''
        self.miscleavages = 0
        
        # clear buffers
        self.reset()
    #----
    
    
    def __add__(self, other):
        """Join sequences and return result (essential for sequence editor)."""
        
        # check value
        if not isinstance(other, sequence):
            raise TypeError, 'Invalid object to join with!'
        
        # check chain type
        if value.chainType != self.chainType:
            raise TypeError, 'Invalid chain type to join with!'
        
        # check cyclic peptides
        if self.cyclic or other.cyclic:
            raise TypeError, 'Cannot join cyclic peptides!'
        
        # break the links
        other = copy.deepcopy(other)
        
        # join sequences
        result = self[:]
        result[len(result):] = other
        
        # set C terminus
        result.cTermFormula = other.cTermFormula
        
        # set neutral loss and gain
        result.fragmentLosses = other.fragmentLosses
        result.fragmentGains = other.fragmentGains
        
        # clear some values
        result.history = [('init', 0, len(self.chain))]
        result.itemBefore = ''
        result.itemAfter = ''
        result.miscleavages = 0
        
        # clear buffers
        result.reset()
        
        return result
    # ----
    
    
    def __iter__(self):
        self._index = 0
        return self
    # ----
    
    
    def next(self):
        if self._index < len(self.chain):
            self._index += 1
            return self.chain[self._index-1]
        else:
            raise StopIteration
    # ----
    
    
    def reset(self):
        """Clear sequence buffers."""
        
        self._formula = None
        self._mass = None
        self._composition = None
    # ----
    
    
    # GETTERS
    
    def duplicate(self):
        """Return copy of current sequence."""
        
        dupl = copy.deepcopy(self)
        dupl.reset()
        
        return dupl
    # ----
    
    
    def count(self, item):
        """Count item in the chain."""
        return self.chain.count(item)
    # ----
    
    
    def formula(self):
        """Get formula."""
        
        # check formula buffer
        if self._formula != None:
            return self._formula
        
        # get composition
        comp = self.composition()
        
        # format composition
        self._formula = ''
        for el in sorted(comp.keys()):
            if comp[el] == 1:
                self._formula += el
            else:
                self._formula += '%s%d' % (el, comp[el])
        
        return self._formula
    # ----
    
    
    def composition(self):
        """Get elemental composition."""
        
        # check composition buffer
        if self._composition != None:
            return self._composition
        
        self._composition = {}
        
        # add monomers to formula
        for monomer in self.chain:
            for el, count in blocks.monomers[monomer].composition.items():
                if el in self._composition:
                    self._composition[el] += count
                else:
                    self._composition[el] = count
        
        # add modifications and labels
        mods = self.modifications + self.labels
        for name, position, state in mods:
            multi = 1
            if type(position) in (str, unicode) and position !='':
                multi = self.chain.count(position)
            for el, count in blocks.modifications[name].composition.items():
                if el in self._composition:
                    self._composition[el] += multi*count
                else:
                    self._composition[el] = multi*count
        
        # add terminal modifications
        if not self.cyclic:
            termCmpd = compound(self.nTermFormula + self.cTermFormula)
            for el, count in termCmpd.composition().items():
                if el in self._composition:
                    self._composition[el] += count
                else:
                    self._composition[el] = count
        
        # subtract neutral losses for fragments
        for loss in self.fragmentLosses:
            lossCmpd = compound(loss)
            for el, count in lossCmpd.composition().items():
                if el in self._composition:
                    self._composition[el] -= count
                else:
                    self._composition[el] = -1*count
        
        # add neutral gains for fragments
        for gain in self.fragmentGains:
            gainCmpd = compound(gain)
            for el, count in gainCmpd.composition().items():
                if el in self._composition:
                    self._composition[el] += count
                else:
                    self._composition[el] = count
        
        # remove zeros
        for atom in self._composition.keys():
            if self._composition[atom] == 0:
                del self._composition[atom]
        
        return self._composition
    # ----
    
    
    def mass(self, massType=None):
        """Get mass."""
        
        # get mass
        if self._mass == None:
            self._mass = compound(self.formula()).mass()
        
        # return mass
        if massType == 0:
            return self._mass[0]
        elif massType ==  1:
            return self._mass[1]
        else:
            return self._mass
    # ----
    
    
    def mz(self, charge, agentFormula='H', agentCharge=1):
        """Get ion m/z"""
        
        return processing.mz(self.mass(),
            charge = charge,
            agentFormula = agentFormula,
            agentCharge = agentCharge
        )
    # ----
    
    
    def pattern(self, fwhm=0.1, threshold=0.01, charge=0, agentFormula='H', agentCharge=1):
        """Get isotopic pattern."""
        
        return processing.pattern(self,
            fwhm = fwhm,
            threshold = threshold,
            charge = charge,
            agentFormula = agentFormula,
            agentCharge = agentCharge
        )
    # ----
    
    
    def format(self, template='S [m]'):
        """Get formated sequence."""
        
        keys = {}
        
        # make sequence keys
        if self.chainType == 'aminoacids':
            keys['S'] = ''.join(self.chain)
            keys['s'] = ''.join(self.chain).lower()
            keys['B'] = self.itemBefore
            keys['A'] = self.itemAfter
            keys['b'] = self.itemBefore.lower()
            keys['a'] = self.itemAfter.lower()
        else:
            keys['S'] = ' | '.join(self.chain)
            keys['s'] = '|'.join(self.chain)
            keys['b'] = self.itemBefore
            keys['a'] = self.itemAfter
            keys['B'] = self.itemBefore
            keys['A'] = self.itemAfter
        
        # make terminal formula keys
        keys['N'] = self.nTermFormula
        keys['C'] = self.cTermFormula
        
        # make modification keys
        keys['m'] = self._formatModifications(self.modifications)
        keys['M'] = self._formatModifications(self.modifications + self.labels)
        keys['l'] = self._formatModifications(self.labels)
        keys['p'] = self.miscleavages
        
        # make history key
        keys['h'] = ''
        if 'h' in template:
            for item in self.history[1:]:
                if item[0] == 'slice':
                    keys['h'] += '[%s-%s]' % (item[1]+1, item[2])
                elif item[0] == 'break':
                    keys['h'] += '[%s|%s]' % (item[1]+1, item[2]+1)
        
        # make fragment name key
        keys['f'] = ''
        if 'f' in template and self.fragmentSerie:
            keys['f'] = self.fragmentSerie
            if self.fragmentIndex != None:
                keys['f'] += str(self.fragmentIndex)
            for gain in self.fragmentGains:
                keys['f'] += ' +'+gain
            for loss in self.fragmentLosses:
                keys['f'] += ' -'+loss
        
        # format
        buff = ''
        for char in template:
            if char in keys:
                buff += keys[char]
            else:
                buff += char
        
        # clear format
        buff = buff.replace('[]', '')
        buff = buff.replace('()', '')
        buff = buff.strip()
        
        return buff
    # ----
    
    
    def search(self, mass, charge, tolerance, enzyme=None, semiSpecific=True, tolUnits='Da', massType=0, maxMods=1, position=False):
        """Search sequence for specified ion.
            mass: (float) m/z value to search for
            charge: (int) charge of the m/z value
            tolerance: (float) mass tolerance
            tolUnits: ('Da', 'ppm') tolerance units
            enzyme: (str) enzyme used for peptides endings, if None H/OH is used
            semiSpecific: (bool) semispecific cleavage is checked (enzyme must be set)
            massType: (0 or 1) mass type of the mass value, 0 = monoisotopic, 1 = average
            maxMods: (int) maximum number of modifications at one residue
            position: (bool) retain position for variable modifications (much slower)
        """
        
        # check cyclic peptides
        if self.cyclic:
            raise TypeError, 'Search function is not supported for cyclic peptides!'
        
        matches = []
        
        # set terminal modifications
        if enzyme:
            enzyme = blocks.enzymes[enzyme]
            expression = re.compile(enzyme.expression+'$')
            nTerm = enzyme.nTermFormula
            cTerm = enzyme.cTermFormula
        else:
            semiSpecific = False
            nTerm = 'H'
            cTerm = 'OH'
        
        # set mass limits
        if tolUnits == 'ppm':
            lowMass = mass - (tolerance * mass/1000000)
            highMass = mass + (tolerance * mass/1000000)
        else:
            lowMass = mass - tolerance
            highMass = mass + tolerance
        
        # search sequence
        length = len(self)
        for i in range(length):
            for j in range(i+1, length+1):
                
                CHECK_FORCE_QUIT()
                
                # get peptide
                peptide = self[i:j]
                if i != 0:
                    peptide.nTerminalFormula = nTerm
                if j != length:
                    peptide.cTerminalFormula = cTerm
                
                # check enzyme specifity
                if semiSpecific and peptide.itemBefore and peptide.itemAfter:
                    if not expression.search(peptide.itemBefore+peptide.chain[0]) and not expression.search(peptide.chain[-1]+peptide.itemAfter):
                        continue
                
                # variate modifications
                variants = peptide.variations(maxMods=maxMods, position=position)
                
                # check mass limits
                peptides = []
                masses = []
                for pep in variants:
                    pepMZ = pep.mz(charge)[massType]
                    peptides.append((pepMZ, pep))
                    masses.append(pepMZ)
                if max(masses) < lowMass:
                    continue
                elif min(masses) > highMass:
                    break
                
                # search for matches
                for pep in peptides:
                    if lowMass <= pep[0] <= highMass:
                        matches.append(pep[1])
        
        return matches
    # ----
    
    
    def variations(self, maxMods=1, position=True, enzyme=None):
        """Calculate all possible combinations of variable modifications.
            maxMods: (int) maximum modifications allowed per one residue
            position: (bool) retain modifications positions (much slower)
            enzyme: (str) enzyme name to ensure that modifications are not presented in cleavage site
        """
        
        variablePeptides = []
        
        # get modifications
        fixedMods = []
        variableMods = []
        for mod in self.modifications:
            if mod[2] == 'f':
                fixedMods.append(mod)
            elif type(mod[1]) == int:
                variableMods.append(mod)
            else:
                if not position:
                    variableMods += [mod] * self.chain.count(mod[1])
                else:
                    for x, symbol in enumerate(self.chain):
                        if symbol == mod[1]:
                            variableMods.append([mod[0], x, 'v'])
        
        # make combinations of variable modifications
        variableMods = self._countUniqueModifications(variableMods)
        combinations = []
        for x in self._uniqueCombinations(variableMods):
            combinations.append(x)
        
        # disable positions occupied by fixed modifications
        occupied = []
        for mod in fixedMods:
            count = max(1, self.chain.count(str(mod[1])))
            occupied += [mod[1]]*count
        
        # disable modifications at cleavage sites
        if enzyme:
            enz = blocks.enzymes[enzyme]
            if not enz.modsBefore and self.itemAfter:
                occupied += [len(self)-1]*maxMods
            if not enz.modsAfter and self.itemBefore:
                occupied += [0]*maxMods
        
        CHECK_FORCE_QUIT()
        
        # filter modifications
        buff = []
        for combination in combinations:
            positions = occupied[:]
            for mod in combination:
                positions += [mod[0][1]]*mod[1]
            if self._checkModifications(positions, self.chain, maxMods):
                buff.append(combination)
        combinations = buff
        
        CHECK_FORCE_QUIT()
        
        # format modifications and filter same
        buff = []
        for combination in combinations:
            mods = []
            for mod in combination:
                if position:
                    mods += [[mod[0][0], mod[0][1], 'f']]*mod[1]
                else:
                    mods += [[mod[0][0],'','f']]*mod[1]
            mods.sort()
            if not mods in buff:
                buff.append(mods)
        combinations = buff
        
        # make new peptides
        for combination in combinations:
            
            CHECK_FORCE_QUIT()
            
            variablePeptide = self.duplicate()
            variablePeptide.modifications[:] = fixedMods+combination
            
            # check composition
            if variablePeptide.isvalid():
                variablePeptides.append(variablePeptide)
        
        return variablePeptides
    # ----
    
    
    def linearized(self, breakPoint=None):
        """Return list of all linearized sequences resulted from cyclic parent."""
        
        # ensure sequence is cyclic
        cyclic = self.cyclic
        self.cyclic = True
        
        # set break points
        breakPoints = range(len(self))
        if breakPoint != None:
            breakPoints = [breakPoint]
        
        # make peptides for all break points
        peptides = []
        for x in breakPoints:
            peptide = self[x:x]
            del peptide.history[-1]
            if x != 0:
                peptide.history.append(('break', x-1, x))
            else:
                peptide.history.append(('break', len(self)-1, x))
            peptides.append(peptide)
        
        # revert to original cyclization
        self.cyclic = cyclic
        
        if breakPoint:
            return peptides[0]
        else:
            return peptides
    # ----
    
    
    def indexes(self):
        """Calculate parent indexes from sequence history."""
        
        ranges = range(self.history[0][1], self.history[0][2])
        for item in self.history[1:]:
            if item[0] == 'slice':
                ranges = ranges[item[1] : item[2]]
            elif item[0] == 'break':
                ranges = ranges[item[2]:]+ranges[:item[1]+1]
        
        return ranges
    # ----
    
    
    def ismodified(self, position=None, strict=False):
        """Check if selected amino acid or whole sequence has any modification.
            position: (int) amino acid index
            strict: (bool) check variable modifications
        """
        
        # check specified position only
        if position != None:
            for mod in self.modifications:
                if (strict or mod[2]=='f') and (mod[1] == position or mod[1] == self.chain[position]):
                    return True
        
        # check whole sequence
        else:
            for mod in self.modifications:
                if strict or mod[2]=='f':
                    return True
        
        # not modified
        return False
    # ----
    
    
    def isvalid(self, charge=0, agentFormula='H', agentCharge=1):
        """Utility to check ion composition."""
        
        # make compound
        formula = compound(self.formula())
        
        # check ion composition
        return formula.isvalid(charge = charge,
            agentFormula = agentFormula,
            agentCharge = agentCharge
        )
    # ----
    
    
    # MODIFIERS
    
    def modify(self, name, position, state='f'):
        """Apply modification to sequence."""
        
        # check modification
        if not name in blocks.modifications:
            raise KeyError, 'Unknown modification! --> ' + name
        
        # check position
        try: position = int(position)
        except: position = str(position)
        if type(position) == str and not position in self.chain:
            return False
        elif type(position) == int and (position < 0 or position >= len(self)):
            return False
        
        # add modification
        self.modifications.append([name, position, str(state)])
        
        # clear buffers
        self.reset()
        
        return True
    # ----
    
    
    def unmodify(self, name=None, position=None, state='f'):
        """Remove modification from sequence."""
        
        # remove all modifications
        if name == None:
            del self.modifications[:]
        
        # remove modification
        else:
            try: mod = [name, int(position), str(state)]
            except: mod = [name, str(position), str(state)]
            while mod in self.modifications:
                del self.modifications[self.modifications.index(mod)]
        
        # clear buffers
        self.reset()
    # ----
    
    
    def label(self, name, position, state='f'):
        """Apply label modification to sequence."""
        
        # check modification
        if not name in blocks.modifications:
            raise KeyError, 'Unknown modification! --> ' + name
        
        # check position
        try: position = int(position)
        except: position = str(position)
        if type(position) == str and not position in self.chain:
            return False
        elif type(position) == int and (position < 0 or position >= len(self)):
            return False
        
        # add label
        self.labels.append([name, position, state])
        
        # clear buffers
        self.reset()
        
        return True
    # ----
    
    
    def cyclize(self, cyclic=True):
        """Make current sequence cyclic/linear."""
        
        # make sequence cyclic
        if cyclic:
            self.cyclic = True
            self.nTermFormula = ''
            self.cTermFormula = ''
        else:
            self.cyclic = False
            self.nTermFormula = 'H'
            self.cTermFormula = 'OH'
        
        # clear buffers
        self.reset()
    # ----
    
    
    # HELPERS
    
    def _formatModifications(self, modifications):
        """Format modifications."""
        
        # get modifications
        modifs = {}
        for mod in modifications:
            
            # count modification
            if mod[1] == '' or type(mod[1]) == int:
                count = 1
            elif type(mod[1]) in (str, unicode):
                count = self.chain.count(mod[1])
            
            # add modification to dic
            if count and mod[0] in modifs:
                modifs[mod[0]] += count
            elif count:
                modifs[mod[0]] = count
        
        # format modifications
        if modifs:
            mods = ''
            for mod in sorted(modifs.keys()):
                mods += '%sx%s; ' % (modifs[mod], mod)
            return '%s' % mods[:-2]
        else:
            return ''
    # ----
    
    
    def _uniqueCombinations(self, items):
        """Generate unique combinations of items."""
        
        for i in range(len(items)):
            for cc in self._uniqueCombinations(items[i+1:]):
                for j in range(items[i][1]):
                    yield [[items[i][0],items[i][1]-j]] + cc
        yield []
    # ----
    
    
    def _countUniqueModifications(self, modifications):
        """Get list of unique modifications with counter."""
        
        uniqueMods = []
        modsCount = []
        for mod in modifications:
            if mod in uniqueMods:
                modsCount[uniqueMods.index(mod)] +=1
            else:
                uniqueMods.append(mod)
                modsCount.append(1)
        
        modsList = []
        for x, mod in enumerate(uniqueMods):
            modsList.append([mod, modsCount[x]])
        
        return modsList
    # ----
    
    
    def _checkModifications(self, positions, chain, maxMods):
        """Check if current modification set is applicable."""
        
        for x in positions:
            count = positions.count(x)
            if type(x) == int:
                if count > maxMods:
                    return False
            elif type(x) in (str, unicode):
                available = chain.count(x)
                for y in positions:
                    if type(y) == int and chain[y] == x:
                        available -= 1
                if count > (available * maxMods):
                    return False
        
        return True
    # ----
    
    


class peak:
    """Peak object definition"""
    
    def __init__(self, mz, ai=0., base=0., sn=None, charge=None, isotope=None, fwhm=None, group=''):
        
        self.mz = float(mz)
        self.ai = float(ai)
        self.base = float(base)
        self.sn = sn
        self.charge = charge
        self.isotope = isotope
        self.fwhm = fwhm
        self.group = group
        
        self.childScanNumber = None
        
        # set intensity
        self.ri = 1.
        self.intensity = self.ai - self.base
        
        # set resolution
        self.resolution = None
        if self.fwhm:
            self.resolution = self.mz/self.fwhm
        
        # set buffers
        self._mass = None
        
        # user defined params
        self.userParams = {}
    # ----
    
    
    def reset(self):
        """Clear peak buffers and set intensity and resolution."""
        
        # clear mass buffer
        self._mass = None
        
        # update intensity
        self.intensity = self.ai - self.base
        
        # update resolution
        self.resolution = None
        if self.fwhm:
            self.resolution = self.mz/self.fwhm
    # ----
    
    
    # GETTERS
    
    def mass(self):
        """Get neutral peak mass."""
        
        # check charge
        if self.charge == None:
            return None
        
        # check mass buffer
        if self._mass != None:
            return self._mass
        
        # calculate neutral mass
        self._mass = processing.mz(self.mz, 0, self.charge, agentFormula='H', agentCharge=1)
        
        return self._mass
    # ----
    
    
    # SETTERS
    
    def setMz(self, mz):
        """Set new m/z value."""
        
        # update value
        self.mz = mz
        
        # update resolution
        self.resolution = None
        if self.fwhm:
            self.resolution = self.mz/self.fwhm
        
        # clear mass buffer
        self._mass = None
    # ----
    
    
    def setAi(self, ai):
        """Set new a.i. value."""
        
        # update value
        self.ai = ai
        
        # update intensity
        self.intensity = self.ai - self.base
    # ----
    
    
    def setBase(self, base):
        """Set new baseline value."""
        
        # update value
        self.base = base
        
        # update intensity
        self.intensity = self.ai - self.base
    # ----
    
    
    def setSN(self, sn):
        """Set new s/n value."""
        self.sn = sn
    # ----
    
    
    def setCharge(self, charge):
        """Set new charge value."""
        
        # update value
        self.charge = charge
        
        # clear mass buffer
        self._mass = None
    # ----
    
    
    def setIsotope(self, isotope):
        """Set new isotope value."""
        self.isotope = isotope
    # ----
    
    
    def setFwhm(self, fwhm):
        """Set new fwhm value."""
        
        # update value
        self.fwhm = fwhm
        
        # update resolution
        self.resolution = None
        if self.fwhm:
            self.resolution = self.mz/self.fwhm
    # ----
    
    
    def setGroup(self, group):
        """Set new group name value."""
        self.group = group
    # ----
    
    


class peaklist:
    """Peaklist object definition."""
    
    def __init__(self, peaks=[]):
        
        # check data
        self.peaks = []
        for item in peaks:
            item = self._checkPeak(item)
            self.peaks.append(item)
        
        # sort peaklist by m/z
        self.sort()
        
        # set basepeak
        self.basepeak = None
        self._setBasepeak()
        
        # set relative intensities
        self._setRelativeIntensities()
    # ----
    
    
    def __len__(self):
        return len(self.peaks)
    # ----
    
    
    def __setitem__(self, i, item):
        
        # check item
        item = self._checkPeak(item)
        
        # basepeak is edited - set new
        if self.peaks[i] is self.basepeak:
            self.peaks[i] = item
            self._setBasepeak()
            self._setRelativeIntensities()
        
        # new basepeak set
        elif self.basepeak and item.intensity > self.basepeak.intensity:
            self.peaks[i] = item
            self.basepeak = item
            self._setRelativeIntensities()
        
        # lower than basepeak
        elif self.basepeak:
            item.ri = item.intensity / self.basepeak.intensity
            self.peaks[i] = item
        
        # no basepeak set
        else:
            self.peaks[i] = item
            self._setBasepeak()
            self._setRelativeIntensities()
        
        # sort peaklist
        self.sort()
    # ----
    
    
    def __getitem__(self, i):
        return self.peaks[i]
    # ----
    
    
    def __delitem__(self, i):
        
        # delete basepeak
        if self.peaks[i] is self.basepeak:
            del self.peaks[i]
            self._setBasepeak()
            self._setRelativeIntensities()
        
        # delete others
        else:
            del self.peaks[i]
    # ----
    
    
    def __iter__(self):
        self._index = 0
        return self
    # ----
    
    
    def __add__(self, other):
        """Return A+B."""
        
        new = self.duplicate()
        new.concatenate(other)
        return new
    # ----
    
    
    def __mul__(self, x):
        """Return A*X."""
        
        new = self.duplicate()
        new.multiply(x)
        return new
    # ----
    
    
    def next(self):
        
        if self._index < len(self.peaks):
            self._index += 1
            return self.peaks[self._index-1]
        else:
            raise StopIteration
    # ----
    
    
    def append(self, item):
        """Append new peak.
            item: (peak or [#, #] or (#,#)) peak to be added
        """
        
        # check peak
        item = self._checkPeak(item)
        
        # add peak and sort peaklist
        if self.peaks and self.peaks[-1].mz > item.mz:
            self.peaks.append(item)
            self.sort()
        else:
            self.peaks.append(item)
        
        # new basepeak set
        if self.basepeak and item.intensity > self.basepeak.intensity:
            self.basepeak = item
            self._setRelativeIntensities()
        
        # lower than basepeak
        elif self.basepeak and self.basepeak.intensity != 0:
            item.ri = item.intensity / self.basepeak.intensity
        
        # no basepeak set
        else:
            item.ri = 1.
            self._setBasepeak()
    # ----
    
    
    def reset(self):
        """Sort peaklist and recalculate basepeak and relative intensities."""
        
        self.sort()
        self._setBasepeak()
        self._setRelativeIntensities()
    # ----
    
    
    # GETTERS
    
    def duplicate(self):
        """Return copy of current peaklist."""
        return copy.deepcopy(self)
    # ----
    
    
    def nextGroupName(self):
        """Get available group name."""
        
        # get used names
        used = []
        for peak in self.peaks:
            if peak.group != None and not peak.group in used:
                used.append(peak.group)
        
        # generate new name
        size = 1
        while True:
            for name in self._generateGroupNames(size):
                if not name in used:
                    return name
            size += 1
    # ----
    
    
    # MODIFIERS
    
    def sort(self):
        """Sort peaks according to m/z."""
        
        buff = []
        for item in self.peaks:
            buff.append((item.mz, item))
        buff.sort()
        
        self.peaks = []
        for item in buff:
            self.peaks.append(item[1])
    # ----
    
    
    def delete(self, indexes=[]):
        """Delete selected peaks.
            indexes: (list or tuple) indexes of peaks to be deleted
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # delete peaks
        indexes.sort()
        indexes.reverse()
        relint = False
        for i in indexes:
            if self.peaks[i] is self.basepeak:
                relint = True
            del self.peaks[i]
        
        # recalculate basepeak and relative intensities
        if relint:
            self._setBasepeak()
            self._setRelativeIntensities()
    # ----
    
    
    def empty(self):
        """Remove all peaks."""
        
        del self.peaks[:]
        self.basepeak = None
    # ----
    
    
    def crop(self, minX, maxX):
        """Delete peaks outside given range.
            minX: (float) lower m/z limit
            maxX: (float) upper m/z limit
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # get indexes to delete
        indexes = []
        for x, peak in enumerate(self.peaks):
            if peak.mz < minX or peak.mz > maxX:
                indexes.append(x)
        
        # delete peaks
        self.delete(indexes)
    # ----
    
    
    def multiply(self, x):
        """Multiply each peak intensity by X.
            x: (int or float) multiplier factor
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # multiply all peaks
        for peak in self.peaks:
            peak.setAi(peak.ai * x)
            peak.setBase(peak.base * x)
        
        # update peaklist
        self._setBasepeak()
        self._setRelativeIntensities()
    # ----
    
    
    def concatenate(self, other):
        """Add data from given peaklist."""
        
        # check peaks
        buff = []
        for peak in copy.deepcopy(other):
            peak = self._checkPeak(peak)
            buff.append(peak)
        
        # store peaks
        self.peaks += buff
        
        # update peaklist
        self.sort()
        self._setBasepeak()
        self._setRelativeIntensities()
    # ----
    
    
    def applyCalibration(self, fce, params):
        """Apply calibration to peaks.
            fce: (function) calibration model
            params: (list or tuple) params for calibration model
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # apply calibration
        for peak in self.peaks:
            peak.setMz(fce(params, peak.mz))
    # ----
    
    
    def findIsotopes(self, maxCharge=1, mzTolerance=0.15, intTolerance=0.5, isotopeShift=0.0):
        """Calculate peak charges and find isotopes.
            maxCharge: (float) max charge to be searched
            mzTolerance: (float) absolute mass tolerance for isotopes
            intTolerance: (float) relative intensity tolerance for isotopes in %/100
            isotopeShift: (float) isotope distance correction (neutral mass)
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # find isotops
        processing.findIsotopes(
            peaklist = self,
            maxCharge = maxCharge,
            mzTolerance = mzTolerance,
            intTolerance = intTolerance,
            isotopeShift = isotopeShift
        )
    # ----
    
    
    def deconvolute(self, massType=0):
        """Recalculate peaklist to singly charged.
            massType: (0 or 1) mass type used for m/z re-calculation, 0 = monoisotopic, 1 = average
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # deconvolute peaklist
        peaks = processing.deconvolute(
            peaklist = self,
            massType = massType
        )
        
        # store data
        self.peaks[:] = peaks.peaks[:]
        
        # update peaklist
        self.sort()
        self._setBasepeak()
        self._setRelativeIntensities()
    # ----
    
    
    def groupPeaks(self, window, forceWindow=False):
        """Group peaks within specified window.
            window: (float) default grouping window
            forceWindow: (bool) use default window for all peaks instead of fwhm
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # group peaks
        buff = []
        buff.append(self.peaks[0])
        for current in self.peaks[1:]:
            previous = buff[-1]
            
            # set window
            win = window
            if not forceWindow and previous.fwhm and current.fwhm:
                win = (previous.fwhm + previous.fwhm) / 4.
            
            # group with previous peak
            if (previous.mz + win) > current.mz:
                
                # get m/z and intensity
                intensity = previous.intensity + current.intensity
                ai = intensity + previous.base
                mz = (previous.mz*previous.intensity + current.mz*current.intensity) / intensity
                
                # set fwhm
                if previous.fwhm and current.fwhm:
                    fwhm = (previous.fwhm*previous.intensity + current.fwhm*current.intensity) / intensity
                    buff[-1].setFwhm(fwhm)
                
                # set peak
                buff[-1].setAi(ai)
                buff[-1].setMz(mz)
            
            # add new peak
            else:
                buff.append(current)
        
        # remove group names
        for peak in buff:
            peak.setGroup('')
        
        # store data
        self.peaks[:] = buff[:]
        
        # update peaklist
        self.sort()
        self._setBasepeak()
        self._setRelativeIntensities()
    # ----
    
    
    def removeBelow(self, absThreshold=0., relThreshold=0., snThreshold=0.):
        """Remove peaks below threshold.
            absThreshold: (float) absolute intensity threshold
            relThreshold: (float) relative intensity threshold
            snThreshold: (float) signal to noise threshold
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # get absolute threshold
        threshold = self.basepeak.intensity * relThreshold
        threshold = max(threshold, absThreshold)
        
        # get indexes to delete
        indexes = []
        for x, peak in enumerate(self.peaks):
            if peak.intensity < threshold or (peak.sn != None and peak.sn < snThreshold):
                indexes.append(x)
        
        # delete peaks
        self.delete(indexes)
    # ----
    
    
    def removeShoulders(self, window=2.5, relThreshold=0.05, fwhm=0.01):
        """Remove shoulder peaks from FTMS data.
            window: (float) peak width multiplier to make search window
            relThreshold: (float) max relative intensity of shoulder/parent peak in %/100
            fwhm: (float) default peak width if not set in peak
        """
        
        # check peaklist
        if not self.peaks:
            return
        
        # get possible parent peaks
        candidates = []
        for peak in self.peaks:
            if not peak.sn or peak.sn*relThreshold > 3:
                candidates.append(peak)
            
        # filter shoulder peaks
        indexes = []
        for parent in candidates:
            
            # get shoulder window
            if parent.fwhm:
                lowMZ = parent.mz - parent.fwhm * window
                highMZ = parent.mz + parent.fwhm * window
            elif fwhm:
                lowMZ = parent.mz - fwhm * window
                highMZ = parent.mz + fwhm * window
            else:
                continue
            
            # get intensity threshold
            intThreshold = parent.intensity * relThreshold
            
            # get indexes to delete
            for x, peak in enumerate(self.peaks):
                if (lowMZ < peak.mz < highMZ) and (peak.intensity < intThreshold) and (not x in indexes):
                    indexes.append(x)
                if peak.mz > highMZ:
                    break
        
        # delete peaks
        self.delete(indexes)
    # ----
    
    
    def removeIsotopes(self):
        """Remove isotopes."""
        
        # check peaklist
        if not self.peaks:
            return
        
        # get indexes to delete
        indexes = []
        for x, peak in enumerate(self.peaks):
            if peak.isotope != 0 and peak.charge != None:
                indexes.append(x)
        
        # delete peaks
        self.delete(indexes)
    # ----
    
    
    def removeUnknown(self):
        """Remove unknown peaks - no charge set."""
        
        # check peaklist
        if not self.peaks:
            return
        
        # get indexes to delete
        indexes = []
        for x, peak in enumerate(self.peaks):
            if peak.charge == None:
                indexes.append(x)
        
        # delete peaks
        self.delete(indexes)
    # ----
    
    
    # HELPERS
    
    def _checkPeak(self, item):
        """Check item to be a valid peak."""
        
        # peak instance
        if isinstance(item, peak):
            return item
        
        # make peak from list or tuple
        elif type(item) in (list, tuple) or len(item)==2:
            return peak(item[0], item[1])
        
        # not valid peak data
        raise TypeError, 'Item must be a peak object or list/tuple of two floats!'
    # ----
    
    
    def _setBasepeak(self):
        """Get most intens peak."""
        
        # check peaklist
        if not self.peaks:
            self.basepeak = None
            return
        
        # set new basepeak
        self.basepeak = self.peaks[0]
        maxInt = self.basepeak.intensity
        for item in self.peaks[1:]:
            if item.intensity > maxInt:
                self.basepeak = item
                maxInt = item.intensity
    # ----
    
    
    def _setRelativeIntensities(self):
        """Set relative intensities for all peaks."""
        
        # check peaklist
        if not self.peaks:
            return
        
        # set relative intensities
        maxInt = self.basepeak.intensity
        if maxInt:
            for item in self.peaks:
                item.ri = item.intensity / maxInt
        else:
            for item in self.peaks:
                item.ri = 1.
    # ----
    
    
    def _generateGroupNames(self, size):
        """Generates serie of group names like A B.. AA AB... AAA AAB.."""
        
        pools = ['ABCDEFGHIJKLMNOPQRSTUVWXYZ'] * size
        result = [[]]
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for prod in result:
            yield ''.join(prod)
    # ----
    


class scan:
    """Scan object definition."""
    
    def __init__(self, points=[], peaks=[]):
        
        self.title = ''
        self.scanNumber = None
        self.parentScanNumber = None
        self.polarity = None
        self.msLevel = None
        self.retentionTime = None
        self.totIonCurrent = None
        self.basePeakMZ = None
        self.basePeakIntensity = None
        self.precursorMZ = None
        self.precursorIntensity = None
        self.precursorCharge = None
        
        # buffers
        self._baseline = None
        self._baselineParams = {'window': None, 'smooth': None, 'offset': None}
        
        # user defined params
        self.userParams = {}
        
        # convert points to numPy array
        self.points = numpy.array(points)
        
        # convert peaks to peaklist
        if not isinstance(peaks, peaklist):
            peaks = peaklist(peaks)
        self.peaklist = peaks
    # ----
    
    
    def __len__(self):
        return len(self.points)
    # ----
    
    
    def __add__(self, other):
        """Return A+B."""
        
        new = self.duplicate()
        new.concatenate(other)
        return new
    # ----
    
    
    def __sub__(self, other):
        """Return A-B."""
        
        new = self.duplicate()
        new.subtract(other)
        return new
    # ----
    
    
    def __mul__(self, x):
        """Return A*X."""
        
        new = self.duplicate()
        new.multiply(x)
        return new
    # ----
    
    
    def reset(self):
        """Clear scan buffers."""
        
        self._baseline = None
        self._baselineParams = {'window': None, 'smooth': None, 'offset': None}
    # ----
    
    
    # GETTERS
    
    def duplicate(self):
        """Return copy of current scan."""
        return copy.deepcopy(self)
    # ----
    
    
    def noise(self, minX=None, maxX=None, mz=None, window=0.1):
        """Return noise level and width for specified m/z range or m/z value.
            minX: (float) lower m/z limit
            maxX: (float) upper m/z limit
            mz: (float) m/z value
            window: (float) percentage around specified m/z value to use for noise calculation
        """
        
        # calculate noise
        return processing.noise(self.points,
            minX = minX,
            maxX = maxX,
            mz = mz,
            window = window
        )
    # ----
    
    
    def baseline(self, window=0.1, smooth=True, offset=0.):
        """Return spectrum baseline data.
            window: (float) noise calculation window in %/100
            smooth: (bool) smooth final baseline
            offset: (float) global intensity offset in %/100
        """
        
        # calculate baseline
        if self._baseline == None \
            or self._baselineParams['window'] != window \
            or self._baselineParams['smooth'] != smooth \
            or self._baselineParams['offset'] != offset:
            
            self._baseline = processing.baseline(self.points, window=window, smooth=smooth, offset=offset)
            self._baselineParams['window'] = window
            self._baselineParams['smooth'] = smooth
            self._baselineParams['offset'] = offset
        
        return self._baseline
    # ----
    
    
    def normalization(self):
        """Return normalization params."""
        
        # calculate range for spectrum and peaklist
        if len(self.points) > 0 and len(self.peaklist) > 0:
            spectrumMax = numpy.maximum.reduce(self.points)[1]
            spectrumMin = numpy.minimum.reduce(self.points)[1]
            peaklistMax = max([peak.ai for peak in self.peaklist])
            peaklistMin = min([peak.base for peak in self.peaklist])
            shift = min(spectrumMin, peaklistMin)
            scale = (max(spectrumMax, peaklistMax)-shift)/100
        
        # calculate range for spectrum only
        elif len(self.points) > 0:
            spectrumMax = numpy.maximum.reduce(self.points)[1]
            shift = numpy.minimum.reduce(self.points)[1]
            scale = (spectrumMax-shift)/100
        
        # calculate range for peaklist only
        elif len(self.peaklist) > 0:
            peaklistMax = max([peak.ai for peak in self.peaklist])
            shift = min([peak.base for peak in self.peaklist])
            scale = (peaklistMax-shift)/100
        
        # no data
        else:
            return 1., 0.
        
        return scale, shift
    # ----
    
    
    def pointsSelection(self, minX, maxX):
        """Return data points for selected m/z range.
            minX: (float) lower m/z limit
            maxX: (float) upper m/z limit
        """
        
        # check slice
        if maxX < minX:
            raise ValueError, 'Invalid slice!'
        
        # crop points
        i1 = processing.findIndex(self.points, minX, dim=2)
        i2 = processing.findIndex(self.points, maxX, dim=2)
        
        return self.points[i1:i2]
    # ----
    
    
    def peakIntensity(self, mz):
        """Return interpolated intensity for given m/z.
            mz: (float) m/z value
        """
        
        # calculate peak intensity
        return processing.peakIntensity(self.points, mz)
    # ----
    
    
    def peakWidth(self, mz, intensity):
        """Return peak width for given m/z and height.
            mz: (float) peak m/z value
            intensity: (float) intensity of width measurement
        """
        
        # calculate peak width
        return processing.peakWidth(self.points, mz, intensity)
    # ----
    
    
    def hasPoints(self):
        """Return number of data points."""
        return len(self.points)
    # ----
    
    
    def hasPeaks(self):
        """Return number of peaks in peaklist."""
        return len(self.peaklist)
    # ----
    
    
    # SETTERS
    
    def setPoints(self, points):
        """Set new point."""
        self.points = points
        self.reset()
    # ----
    
    
    def setPeaklist(self, peaks):
        """Set new peaklist."""
        
        # convert peaks to peaklist
        if isinstance(peaks, peaklist):
            self.peaklist = peaks
        else:
            self.peaklist = peaklist(peaks)
    # ----
    
    
    # MODIFIERS
    
    def swap(self):
        """Swap data between spectrum and peaklist."""
        
        # make new spectrum
        points = [[i.mz, i.ai] for i in self.peaklist]
        points = numpy.array(points)
        
        # make new peaklist
        peaks = [peak(i[0],i[1]) for i in self.points]
        peaks = peaklist(peaks)
        
        # update document
        self.points = points
        self.peaklist = peaks
        
        # clear buffers
        self.reset()
    # ----
    
    
    def crop(self, minX, maxX):
        """Crop data points and peaklist.
            minX: (float) lower m/z limit
            maxX: (float) upper m/z limit
        """
        
        # crop spectrum data
        i1 = processing.findIndex(self.points, minX, dim=2)
        i2 = processing.findIndex(self.points, maxX, dim=2)
        self.points = self.points[i1:i2]
        
        # crop peaklist data
        self.peaklist.crop(minX, maxX)
        
        # clear buffers
        self.reset()
    # ----
    
    
    def normalize(self):
        """Normalize data points and peaklist."""
        
        # get normalization params
        normalization = self.normalization()
        
        # normalize spectrum points
        if len(self.points) > 0:
            self.points -= numpy.array((0, normalization[1]))
            self.points /= numpy.array((1, normalization[0]))
        
        # normalize peaklist
        if len(self.peaklist) > 0:
            for peak in self.peaklist:
                peak.setAi((peak.ai - normalization[1]) / normalization[0])
                peak.setBase((peak.base - normalization[1]) / normalization[0])
            self.peaklist.reset()
        
        # clear buffers
        self.reset()
    # ----
    
    
    def multiply(self, x):
        """Multiply data points and peaklist by X.
            x: (int or float) multiplier factor
        """
        
        # multiply spectrum
        if len(self.points):
            self.points *= numpy.array((1.0, x))
        
        # multiply peakslist
        self.peaklist.multiply(x)
        
        # clear buffers
        self.reset()
    # ----
    
    
    def concatenate(self, other):
        """Add data from given scan."""
        
        # check scan
        if not isinstance(other, scan):
            raise TypeError, "Cannot concatenate with non-scan object!"
        
        # use spectra only
        if len(self.points) or len(other.points):
            
            # unify raster
            data = processing.unifyRaster(self.points, other.points)
            
            # convert back to arrays
            pointsA = numpy.array(data[0])
            pointsB = numpy.array(data[1])
            
            # remove X axis from points B
            pointsB[:,0] = 0
            
            # concatenate points
            self.points = pointsA + pointsB
            
            # empty peaklist
            self.peaklist.empty()
        
        # use peaklists only
        elif len(self.peaklist) or len(other.peaklist):
            self.peaklist.concatenate(other.peaklist)
        
        # clear buffers
        self.reset()
    # ----
    
    
    def subtract(self, other):
        """Subtract given data points from current scan."""
        
        # check scan
        if not isinstance(other, scan):
            raise TypeError, "Cannot subtract non-scan object!"
        
        # use spectra only
        if len(self.points) and len(other.points):
            
            # unify raster
            data = processing.unifyRaster(self.points, other.points)
            
            # convert back to arrays
            pointsA = numpy.array(data[0])
            pointsB = numpy.array(data[1])
            
            # remove X axis from points B
            pointsB[:,0] = 0
            
            # subtract points
            self.points = pointsA - pointsB
            
            # empty peaklist
            self.peaklist.empty()
            
            # clear buffers
            self.reset()
    # ----
    
    
    def smooth(self, method, window, cycles=1):
        """Smooth data points.
            method: ('MA', 'GA' or 'SG') smoothing method, MA - moving average, GA - Gaussian, SG - Savitzky-Golay
            window: (float) m/z window size for smoothing
            cycles: (int) number of repeating cycles
        """
        
        # apply moving average filter
        if method.upper() == 'MA':
            points = processing.smoothMA(self.points, window, cycles)
        
        # apply Gaussian filter
        elif method.upper() == 'GA':
            points = processing.smoothGA(self.points, window, cycles)
        
        # apply Savitzky-Golay filter
        elif method.upper() == 'SG':
            points = processing.smoothSG(self.points, window, cycles)
        
        # unknown method
        else:
            raise KeyError, "Unknown smoothing method! --> " + method
        
        # store data
        self.points = points
        self.peaklist.empty()
        
        # clear buffers
        self.reset()
    # ----
    
    
    def applyCalibration(self, fce, params):
        """Apply calibration to data points and peaklist.
            fce: (function) calibration model
            params: (list or tuple) params for calibration model
        """
        
        # calibrate data points
        for x, point in enumerate(self.points):
            self.points[x][0] = fce(params, point[0])
        
        # calibrate peaklist
        self.peaklist.applyCalibration(fce, params)
        
        # clear buffers
        self.reset()
    # ----
    
    
    def correctBaseline(self, window=0.1, smooth=True, offset=0.):
        """Subtract baseline from data points.
            window: (float) noise calculation window in %/100
            smooth: (bool) smooth final baseline
            offset: (float) global intensity offset in %/100
        """
        
        # correct baseline
        points = processing.correctBaseline(
            points = self.points,
            window = window,
            smooth = smooth,
            offset = offset
        )
        
        # store data
        self.points = points
        self.peaklist.empty()
        
        # clear buffers
        self.reset()
    # ----
    
    
    def labelScan(self, pickingHeight=0.75, absThreshold=0., relThreshold=0., snThreshold=0., baselineWindow=0.1, baselineSmooth=True, baselineOffset=0., smoothMethod=None, smoothWindow=0.2, smoothCycles=1):
        """Label centroides in current scan.
            pickingHeight: (float) peak picking height for centroiding
            absThreshold: (float) absolute intensity threshold
            relThreshold: (float) relative intensity threshold
            snThreshold: (float) signal to noise threshold
            baselineWindow: (float) noise calculation window in %/100
            baselineSmooth: (bool) smooth baseline
            baselineOffset: (float) baseline intensity offset in %/100
            smoothMethod: (None, MA, GA or SG) smoothing method, MA - moving average, GA - Gaussian, SG - Savitzky-Golay
            smoothWindows: (float) m/z window size for smoothing
            smoothCycles: (int) number of repeating cycles
        """
        
        # label scan
        newPeaklist = processing.labelScan(
            points = self.points,
            pickingHeight = pickingHeight,
            absThreshold = absThreshold,
            relThreshold = relThreshold,
            snThreshold = snThreshold,
            baselineWindow = baselineWindow,
            baselineSmooth = baselineSmooth,
            baselineOffset = baselineOffset,
            smoothMethod = smoothMethod,
            smoothWindow = smoothWindow,
            smoothCycles = smoothCycles
        )
        
        # update peaklist
        if newPeaklist != None:
            self.peaklist = newPeaklist
            return True
        else:
            return False
    # ----
    
    
    def labelPeak(self, mz=None, minX=None, maxX=None, pickingHeight=0.75, baselineWindow=0.1, baselineSmooth=True, baselineOffset=0., baselineData=None):
        """Return labeled peak in given m/z range.
            mz: (float) single m/z value
            minX: (float) starting m/z value
            maxX: (float) ending m/z value
            pickingHeight: (float) peak picking height for centroiding
            baselineWindow: (float) noise calculation window in %/100
            baselineSmooth: (bool) smooth baseline
            baselineOffset: (float) baseline intensity offset in %/100
            baselineData: (list of [x, noiseLevel, noiseWidth]) precalculated baseline
        """
        
        # label peak
        newPeak = processing.labelPeak(
            points = self.points,
            mz = mz,
            minX = minX,
            maxX = maxX,
            pickingHeight = pickingHeight,
            baselineWindow = baselineWindow,
            baselineSmooth = baselineSmooth,
            baselineOffset = baselineOffset,
            baselineData = baselineData
        )
        
        # append peak
        if newPeak:
            self.peaklist.append(newPeak)
            return True
        else:
            return False
    # ----
    
    
    def labelPoint(self, mz, baselineWindow=0.1, baselineSmooth=True, baselineOffset=0., baselineData=None):
        """Label peak at given m/z value.
            mz: (float) m/z value to label
            baselineWindow: (float) noise calculation window in %/100
            baselineSmooth: (bool) smooth baseline
            baselineOffset: (float) baseline intensity offset in %/100
            baselineData: (list of [x, noiseLevel, noiseWidth]) precalculated baseline
        """
        
        # label point
        newPeak = processing.labelPoint(
            points = self.points,
            mz = mz,
            baselineWindow = baselineWindow,
            baselineSmooth = baselineSmooth,
            baselineOffset = baselineOffset,
            baselineData = baselineData
        )
        
        # append peak
        if newPeak:
            self.peaklist.append(newPeak)
            return True
        else:
            return False
    # ----
    
    
    def findIsotopes(self, maxCharge=1, mzTolerance=0.15, intTolerance=0.5, isotopeShift=0.0):
        """Calculate peak charges and find isotopes.
            maxCharge: (float) max charge to be searched
            mzTolerance: (float) absolute mass tolerance for isotopes
            intTolerance: (float) relative intensity tolerance for isotopes in %/100
            isotopeShift: (float) isotope distance correction (neutral mass)
        """
        
        # find istopes
        self.peaklist.findIsotopes(
            maxCharge = maxCharge,
            mzTolerance = mzTolerance,
            intTolerance = intTolerance,
            isotopeShift = isotopeShift
        )
    # ----
    
    
    def deconvolute(self, massType=0):
        """Recalculate peaklist to singly charged.
            massType: (0 or 1) mass type used for m/z re-calculation, 0 = monoisotopic, 1 = average
        """
        
        # delete spectrum points
        self.points = numpy.array([])
        
        # deconvolute peaklist
        self.peaklist.deconvolute(massType=massType)
        
        # clear buffers
        self.reset()
    # ----
    
    
    def groupPeaks(self, window, forceWindow=False):
        """Group peaks within specified window.
            window: (float) default grouping window
            forceWindow: (bool) use default window for all peaks instead of fwhm
        """
        
        self.peaklist.groupPeaks(
            window = window,
            forceWindow = forceWindow
        )
    # ----
    
    
    def removeBelow(self, absThreshold=0., relThreshold=0., snThreshold=0.):
        """Remove peaks below threshold.
            absThreshold: (float) absolute intensity threshold
            relThreshold: (float) relative intensity threshold
            snThreshold: (float) signal to noise threshold
        """
        
        self.peaklist.removeBelow(
            absThreshold = absThreshold,
            relThreshold = relThreshold,
            snThreshold = snThreshold
        )
    # ----
    
    
    def removeShoulders(self, window=2.5, relThreshold=0.05, fwhm=0.01):
        """Remove shoulder peaks from current peaklist.
            window: (float) peak width multiplier to make search window
            relThreshold: (float) max relative intensity of shoulder/parent peak in %/100
            fwhm: (float) default peak width if not set in peak
        """
        
        self.peaklist.removeShoulders(
            window = window,
            relThreshold = relThreshold,
            fwhm = fwhm
        )
    # ----
    
    
    def removeIsotopes(self):
        """Remove isotopes from current peaklist."""
        self.peaklist.removeIsotopes()
    # ----
    
    
    def removeUnknown(self):
        """Remove unknown peaks (no charge set) from current peaklist."""
        self.peaklist.removeUnknown()
    # ----
    
    

