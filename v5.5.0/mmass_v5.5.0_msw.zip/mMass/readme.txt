FOREWORD
--------

Thank you very much for your interest in this simple mass spec tool. First of
all, I have to mention some important things, such as:

I am not a programmer by training! Programming is just my hobby and I am doing
it for fun. Therefore you should not expect mMass to be perfect or even
usable. The coding style is probably horrible and trying to read the code may
seriously affect your mental health :) You are however welcome to read
the code, modify it and send me any suggestions or patches. I'm still
learning. On the other hand don't flame me about the style - you have been
warned. Any reports on bugs are also welcome.


LICENSE
-------

This program and its documentation are Copyright 2005-2013 by Martin Strohalm.

This program, along with all associated documentation, is free software;
you can redistribute it and/or modify it under the terms of the GNU General
Public License as published by the Free Software Foundation.
See the LICENSE.TXT file for details (and make sure that you have entirely
read and understood it!)

Please note in particular that, if you use this program, or ANY part of it
- even a single line of code - in another application, the resulting
application becomes also GPL. In other words, GPL is a "contaminating"
license.

If you do not understand any portion of this notice, please seek appropriate
professional legal advice. If you do not or - for any reason - you can not
accept ALL of these conditions, then you must not use nor distribute this
program.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
(file LICENSE.TXT) for more details.

The origin of this software must not be misrepresented; you must not claim
that you wrote the original software. Altered source versions must be clearly
marked as such, and must not be misrepresented as being the original software.

This notice must not be removed or altered from any source distribution.


AUTHOR
------
Martin STROHALM
http://www.mmass.org/


Thank you for your interest, and ... have fun!
